<?php
    header("location:../login");
?>